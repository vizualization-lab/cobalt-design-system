Cobalt Design System Fonts Package

This package contains installable TrueType variable fonts for designers creating Cobalt mockups and prototypes.

Included families:
- Inter Variable: primary sans family for Cobalt UI text.
- Noto Sans Variable: sans fallback for broader script support.
- JetBrains Mono Variable: mono family for code, technical labels, and token values.

Install these .ttf files in your operating system or design software font manager, then restart your design tool if the fonts do not appear immediately.

These fonts are distributed under the SIL Open Font License 1.1. License files are included in the licenses folder.

Sources:
- Inter: https://github.com/google/fonts/tree/main/ofl/inter
- Noto Sans: https://github.com/google/fonts/tree/main/ofl/notosans
- JetBrains Mono: https://github.com/google/fonts/tree/main/ofl/jetbrainsmono
