# Cobalt Packages

This folder contains locally packed Cobalt npm packages for teams that cannot install from the private Cobalt npm registry.

## Use with npm create cobalt

Create a project in local package mode:

```bash
npm create cobalt my-app -- --cobalt-source local
```

Copy this `cobalt-packages` folder into the generated project before installing dependencies:

```bash
cp -R cobalt-packages my-app/cobalt-packages
cd my-app
pnpm install
pnpm dev
```

## Use the included starter generator without registry access

If you cannot install `create-cobalt` from a registry, run it from the included tarball:

```bash
npm exec --package ./cobalt-packages/create-cobalt-0.1.0.tgz -- create-cobalt my-app --cobalt-source local
```

## Included packages

- cobalt-angular-0.1.0.tgz
- cobalt-components-0.1.0.tgz
- cobalt-icons-0.1.0.tgz
- cobalt-react-0.1.0.tgz
- cobalt-tokens-0.1.0.tgz
- cobalt-vue-0.1.0.tgz
- create-cobalt-0.1.0.tgz
